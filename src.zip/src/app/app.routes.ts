import { Routes } from '@angular/router';
import { SidenavComponent } from './layout/sidenav/sidenav.component';

export const routes: Routes = [
    {
path: '',
component: SidenavComponent
    }


];

